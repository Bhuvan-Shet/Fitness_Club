package com.fitness.dto;

public class Appointment {
    private int id;
    private String trainerEmail;
    private String userEmail;
    private int months;
    private int hoursPerDay;
    private String status;

    // Getters and Setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getTrainerEmail() {
        return trainerEmail;
    }
    public void setTrainerEmail(String trainerEmail) {
        this.trainerEmail = trainerEmail;
    }

    public String getUserEmail() {
        return userEmail;
    }
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public int getMonths() {
        return months;
    }
    public void setMonths(int months) {
        this.months = months;
    }

    public int getHoursPerDay() {
        return hoursPerDay;
    }
    public void setHoursPerDay(int hoursPerDay) {
        this.hoursPerDay = hoursPerDay;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
}
