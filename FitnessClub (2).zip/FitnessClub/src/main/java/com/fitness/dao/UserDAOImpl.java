package com.fitness.dao;



import com.fitness.dto.User;
import com.fitness.dao.UserDAO;
import com.fitness.dbconn.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAOImpl implements UserDAO {

    // Method to handle user login
    @Override
    public boolean login(String email, String password) {
        boolean status = false;
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM users WHERE email = ? AND password = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, email);
            ps.setString(2, password);
            status = ps.executeQuery().next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    // Method to handle user signup
    @Override
    public boolean signup(User user) {
        boolean result = false;
        try (Connection conn = DBConnection.getConnection()) {
            // SQL query to insert a new user
            String query = "INSERT INTO users (name, email, phone, dob, password) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, user.getName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPhone());
            ps.setString(4, user.getDob());
            ps.setString(5, user.getPassword());

            // Execute the query and check if the insertion was successful
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                result = true; // Successful signup
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    
    public User getUserByEmail(String email) {
        User user = null;
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM users WHERE email = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                user = new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setPhone(rs.getString("phone"));
                user.setDob(rs.getString("dob"));
                user.setPassword(rs.getString("password"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    
    @Override
    public boolean updateUser(User user) {
        boolean updated = false;
        String sql = "UPDATE users SET name=?, phone=?, dob=?, password=? WHERE email=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setString(1, user.getName());
            ps.setString(2, user.getPhone());
            ps.setString(3, user.getDob());
            ps.setString(4, user.getPassword());
            ps.setString(5, user.getEmail());

            int rowsAffected = ps.executeUpdate();
            updated = rowsAffected > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return updated;
    }

}
