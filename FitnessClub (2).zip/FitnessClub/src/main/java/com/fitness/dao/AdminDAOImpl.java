package com.fitness.dao;


import com.fitness.dao.AdminDAO;
import com.fitness.dto.Admin;
import com.fitness.dbconn.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminDAOImpl implements AdminDAO {
   
    @Override
    public boolean login(String email, String password) {
        boolean status = false;
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM admins WHERE email = ? AND password = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            status = rs.next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }
}
