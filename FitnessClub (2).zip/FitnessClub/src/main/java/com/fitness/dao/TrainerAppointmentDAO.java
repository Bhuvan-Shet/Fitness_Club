package com.fitness.dao;

import java.util.List;

import com.fitness.dto.Appointment;
import com.fitness.dto.TrainerAppointment;

public interface TrainerAppointmentDAO {
    boolean bookAppointment(TrainerAppointment appointment);
    List<Appointment> getAppointmentsForTrainer(String trainerEmail);
    boolean updateAppointmentStatus(int appointmentId, String status);
}

