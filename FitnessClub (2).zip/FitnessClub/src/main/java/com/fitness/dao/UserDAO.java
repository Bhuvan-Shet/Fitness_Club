package com.fitness.dao;

import com.fitness.dto.User;

public interface UserDAO {
    // Method for user login
    boolean login(String email, String password);

    // Method for user signup
    boolean signup(User user);
    
    User getUserByEmail(String email);
    
    boolean updateUser(User user);
}
