package com.fitness.dao;
import com.fitness.dto.CartItem;
import com.fitness.dto.Product;
import com.fitness.dbconn.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartDAOImpl implements CartDAO {
    @Override
    public boolean addToCart(String userEmail, int productId, int quantity) {
        boolean status = false;
        try (Connection conn = DBConnection.getConnection()) {
            String query = "INSERT INTO cart_items(user_email, product_id, quantity, status) VALUES (?, ?, ?, 'Pending')";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, userEmail);
            ps.setInt(2, productId);
            ps.setInt(3, quantity);
            status = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    @Override
    public List<CartItem> getCartItemsByUser(String userEmail) {
        List<CartItem> cartItems = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT c.id as cart_id, c.quantity, c.status, p.id as product_id, p.name, p.price, p.image_url " +
                           "FROM cart_items c JOIN products p ON c.product_id = p.id WHERE c.user_email = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, userEmail);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                CartItem ci = new CartItem();
                ci.setId(rs.getInt("cart_id"));
                ci.setUserEmail(userEmail);
                ci.setQuantity(rs.getInt("quantity"));
                ci.setStatus(rs.getString("status"));

                Product p = new Product();
                p.setId(rs.getInt("product_id"));
                p.setName(rs.getString("name"));
                p.setPrice(rs.getDouble("price"));
                p.setImageUrl(rs.getString("image_url"));
                ci.setProduct(p);

                cartItems.add(ci);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cartItems;
    }

    @Override
    public boolean updateStatus(int cartItemId, String status) {
        boolean updated = false;
        try (Connection conn = DBConnection.getConnection()) {
            String query = "UPDATE cart_items SET status = ? WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, status);
            ps.setInt(2, cartItemId);
            updated = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return updated;
    }
    
    public void deleteCartItemById(int cartItemId) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "DELETE FROM cart_items WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, cartItemId);
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteCartItemsByUser(String userEmail) {
        String sql = "DELETE FROM cart WHERE userEmail = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, userEmail);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void clearCartByUser(String userEmail) {
        String sql = "DELETE FROM cart_items WHERE user_email = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userEmail);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    
    
}