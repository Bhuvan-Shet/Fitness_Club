package com.fitness.dao;

import java.util.List;

import com.fitness.dto.CartItem;

public interface CartDAO {
	boolean addToCart(String userEmail, int productId, int quantity);
    List<CartItem> getCartItemsByUser(String userEmail);
    boolean updateStatus(int cartItemId, String status);
    void deleteCartItemById(int cartItemId);
    void deleteCartItemsByUser(String userEmail);
    void clearCartByUser(String userEmail);
}
