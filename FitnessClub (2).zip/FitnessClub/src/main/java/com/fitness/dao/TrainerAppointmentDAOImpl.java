package com.fitness.dao;

import com.fitness.dbconn.DBConnection;
import com.fitness.dto.Appointment;
import com.fitness.dto.TrainerAppointment;
import java.sql.*;
import java.util.*;

public class TrainerAppointmentDAOImpl implements TrainerAppointmentDAO {
    private Connection conn = DBConnection.getConnection();

    @Override
    public boolean bookAppointment(TrainerAppointment app) {
        String sql = "INSERT INTO trainer_appointments (user_email, trainer_id, months, hours_per_day, status) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, app.getUserEmail());
            ps.setInt(2, app.getTrainerId());
            ps.setInt(3, app.getMonths());
            ps.setInt(4, app.getHoursPerDay());
            ps.setString(5, "Pending");
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Appointment> getAppointmentsForTrainer(String trainerEmail) {
        List<Appointment> list = new ArrayList<>();

        String sql = "SELECT * FROM appointments WHERE trainerEmail = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, trainerEmail);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Appointment a = new Appointment();
                a.setId(rs.getInt("id"));
                a.setTrainerEmail(rs.getString("trainerEmail"));
                a.setUserEmail(rs.getString("userEmail"));
                a.setMonths(rs.getInt("months"));
                a.setHoursPerDay(rs.getInt("hoursPerDay"));
                a.setStatus(rs.getString("status"));

                list.add(a);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public boolean updateAppointmentStatus(int appointmentId, String status) {
        String sql = "UPDATE appointments SET status = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, status);
            ps.setInt(2, appointmentId);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
