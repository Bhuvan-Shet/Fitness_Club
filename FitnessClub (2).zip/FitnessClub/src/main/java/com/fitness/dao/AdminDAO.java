package com.fitness.dao;

import com.fitness.dto.Admin;

public interface AdminDAO {
	
	    boolean login(String email, String password);

}
