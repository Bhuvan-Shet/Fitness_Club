package com.fitness.dao;

import java.util.List;

import com.fitness.dto.Product;

public interface ProductDAO {

	List<Product> getProductsBysubcategory(String subcategory); // e.g. "SportyTankTop"
    Product getProductById(int id);
}
