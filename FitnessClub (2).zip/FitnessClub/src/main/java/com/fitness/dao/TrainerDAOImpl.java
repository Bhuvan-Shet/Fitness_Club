package com.fitness.dao;


import com.fitness.dto.Trainer;
import com.fitness.dao.TrainerDAO;
import com.fitness.dbconn.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class TrainerDAOImpl implements TrainerDAO {

    public boolean signup(Trainer trainer) {
        boolean status = false;
        try (Connection conn = DBConnection.getConnection()) {
            String query = "INSERT INTO trainers(name, email, phone, specialization, password) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, trainer.getName());
            ps.setString(2, trainer.getEmail());
            ps.setString(3, trainer.getPhone());
            ps.setString(4, trainer.getSpecialization());
            ps.setString(5, trainer.getPassword());
            status = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    @Override
    public String login(String email, String password) {
        String trainerName = null;
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT name FROM trainers WHERE email = ? AND password = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                trainerName = rs.getString("name");  // Get the trainer's name from the database
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return trainerName;
    }
    
    public List<Trainer> getAllTrainers() {
        List<Trainer> trainers = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM trainers");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Trainer t = new Trainer();
                t.setId(rs.getInt("id"));
                t.setName(rs.getString("name"));
                t.setEmail(rs.getString("email"));
                t.setPhone(rs.getString("phone"));
                t.setSpecialization(rs.getString("specialization"));
                t.setPassword(rs.getString("password")); // optional to set

                trainers.add(t);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return trainers;
    }
    
    @Override
    public boolean updateTrainer(Trainer trainer) {
        boolean result = false;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                 "UPDATE trainers SET name=?, phone=?, specialization=?, password=? WHERE email=?")) {

            ps.setString(1, trainer.getName());
            ps.setString(2, trainer.getPhone());
            ps.setString(3, trainer.getSpecialization());
            ps.setString(4, trainer.getPassword());
            ps.setString(5, trainer.getEmail());

            result = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    
    @Override
    public Trainer getTrainerByEmail(String email) {
        Trainer trainer = null;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM trainers WHERE email = ?")) {

            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                trainer = new Trainer();
                trainer.setId(rs.getInt("id"));
                trainer.setName(rs.getString("name"));
                trainer.setEmail(rs.getString("email"));
                trainer.setPhone(rs.getString("phone"));
                trainer.setSpecialization(rs.getString("specialization"));
                trainer.setPassword(rs.getString("password"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return trainer;
    }



}
