package com.fitness.dao;

import java.util.List;

import com.fitness.dto.Trainer;

public interface TrainerDAO {
	boolean signup(Trainer trainer);
    String login(String email, String password);
    List<Trainer> getAllTrainers();
    boolean updateTrainer(Trainer trainer);
    public Trainer getTrainerByEmail(String email);



}
