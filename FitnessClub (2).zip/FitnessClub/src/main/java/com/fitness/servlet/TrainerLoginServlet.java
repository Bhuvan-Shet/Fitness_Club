package com.fitness.servlet;

import com.fitness.dao.TrainerDAO;
import com.fitness.dao.TrainerDAOImpl;
import com.fitness.dto.Trainer;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;


@WebServlet("/loginTrainerServlet")
public class TrainerLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        TrainerDAO trainerDAO = new TrainerDAOImpl();
        String trainerName = trainerDAO.login(email, password);  // Get the trainer's name

        if (trainerName != null) {
            // Use the existing session if available, otherwise create a new one
            HttpSession session = request.getSession(false);
            if (session == null) {
                session = request.getSession();  // Create a new session
            }
            session.setAttribute("trainerEmail", email);
            session.setAttribute("trainerName", trainerName);  // Store the actual trainer name
            response.sendRedirect("Trainer/TrainerDashboard.jsp");
        } else {
            response.sendRedirect("LoginTrainer.jsp?error=Invalid credentials");
        }
    }
}

