package com.fitness.servlet;



import com.fitness.dao.TrainerDAO;
import com.fitness.dao.TrainerDAOImpl;
import com.fitness.dto.Trainer;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class UpdateTrainerProfileServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String specialization = request.getParameter("specialization");
        String password = request.getParameter("password");

        Trainer trainer = new Trainer();
        trainer.setName(name);
        trainer.setEmail(email);
        trainer.setPhone(phone);
        trainer.setSpecialization(specialization);
        trainer.setPassword(password);

        TrainerDAO dao = new TrainerDAOImpl();
        boolean success = dao.updateTrainer(trainer);

        if (success) {
            request.setAttribute("message", "Profile updated successfully.");
        } else {
            request.setAttribute("message", "Failed to update profile.");
        }
        RequestDispatcher rd = request.getRequestDispatcher("TrainerProfile.jsp");
        rd.forward(request, response);
    }
}
