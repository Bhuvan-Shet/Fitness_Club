package com.fitness.servlet;

import com.fitness.dao.UserDAO;
import com.fitness.dao.UserDAOImpl;
import com.fitness.dto.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/signupServlet")
public class UserSignupServlet extends HttpServlet {

    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        userDAO = new UserDAOImpl(); // Initialize the DAO object
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String dob = request.getParameter("dob");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        // Basic validation
        if (password.equals(confirmPassword)) {
            User user = new User();
            user.setName(name);
            user.setEmail(email);
            user.setPhone(phone);
            user.setDob(dob);
            user.setPassword(password);

            // Call the DAO method to save the user to the database
            boolean result = userDAO.signup(user);

            if (result) {
                response.sendRedirect("login.jsp"); // Redirect to login page after successful signup
            } else {
                request.setAttribute("error", "Signup failed, try again.");
                request.getRequestDispatcher("signup.jsp").forward(request, response); // Show signup page with error message
            }
        } else {
            request.setAttribute("error", "Passwords do not match.");
            request.getRequestDispatcher("signup.jsp").forward(request, response); // Show signup page with error message
        }
    }
}
