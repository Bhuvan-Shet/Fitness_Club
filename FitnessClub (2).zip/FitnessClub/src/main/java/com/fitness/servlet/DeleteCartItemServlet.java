package com.fitness.servlet;

import com.fitness.dao.CartDAO;
import com.fitness.dao.CartDAOImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/DeleteCartItemServlet")
public class DeleteCartItemServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String cartItemIdParam = request.getParameter("cartItemId");

        if (cartItemIdParam != null) {
            int cartItemId = Integer.parseInt(cartItemIdParam);
            CartDAO cartDAO = new CartDAOImpl();
            cartDAO.deleteCartItemById(cartItemId);
        }

        // Redirect back to cart.jsp
        response.sendRedirect("cart.jsp");
    }
}
