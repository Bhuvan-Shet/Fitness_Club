package com.fitness.servlet;

import com.fitness.dao.UserDAO;
import com.fitness.dao.UserDAOImpl;
import com.fitness.dto.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/loginServlet")
public class UserLoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        UserDAO userDAO = new UserDAOImpl();
        User user = userDAO.getUserByEmail(email);  // You must implement this method

        if (user != null && user.getPassword().equals(password)) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user); // Store the entire user object
            session.setAttribute("userEmail", user.getEmail());
            response.sendRedirect("UserDashboard.jsp");
        } else {
            response.sendRedirect("loginUser.jsp?error=Invalid credentials");
        }
    }
}
