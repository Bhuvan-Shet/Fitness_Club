package com.fitness.servlet;

import com.fitness.dao.CartDAO;
import com.fitness.dao.CartDAOImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/PaymentServlet")
public class PaymentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String userEmail = (String) session.getAttribute("userEmail");

        if (userEmail != null) {
            CartDAO cartDAO = new CartDAOImpl();

            // Clear the cart items for this user
            cartDAO.clearCartByUser(userEmail);

            // Set one-time success message in session
            session.setAttribute("paymentSuccessMessage", "Payment successful! Your cart items have been delivered.");
        }

        // Redirect back to cart.jsp to show empty cart and message
        response.sendRedirect("cart.jsp");
    }
}
