package com.fitness.servlet;

import com.fitness.dao.AdminDAO;
import com.fitness.dao.AdminDAOImpl;
import com.fitness.dto.Admin;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;



@WebServlet("/loginAdminServlet")
public class AdminLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = "admin@fitness.com"; // Predefined admin email
        String password = "admin123"; // Predefined admin password

        AdminDAO adminDAO = new AdminDAOImpl();
        boolean isLoggedIn = adminDAO.login(email, password);

        if (isLoggedIn) {
            HttpSession session = request.getSession();
            session.setAttribute("adminEmail", email);
            response.sendRedirect("AdminDashboard.jsp");
        } else {
            response.sendRedirect("LoginAdmin.jsp?error=Invalid credentials");
        }
    }
}