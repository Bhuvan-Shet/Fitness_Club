package com.fitness.servlet;

import com.fitness.dao.UserDAO;
import com.fitness.dao.UserDAOImpl;
import com.fitness.dto.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/updateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get existing session, don't create a new one if none exists
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userEmail") == null) {
            // User not logged in, redirect to login page
            response.sendRedirect("loginUser.jsp?error=Please login first");
            return;
        }

        // Get logged-in user's email from session (more secure than reading from form)
        String email = (String) session.getAttribute("userEmail");

        // Get updated fields from request (except email)
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String dob = request.getParameter("dob");
        String password = request.getParameter("password");

        // You should validate input here (not shown for brevity)

        // Create User DTO and set updated info
        User updatedUser = new User();
        updatedUser.setEmail(email);  // email is fixed from session
        updatedUser.setName(name);
        updatedUser.setPhone(phone);
        updatedUser.setDob(dob);

        // TODO: Ideally, hash password before storing
        updatedUser.setPassword(password);

        UserDAO userDAO = new UserDAOImpl();
        boolean isUpdated = userDAO.updateUser(updatedUser);

        if (isUpdated) {
            // Reload fresh user from DB to update session info
            User refreshedUser = userDAO.getUserByEmail(email);

            // Update session attribute (store whole User object for convenience)
            session.setAttribute("loggedInUser", refreshedUser);

            // Redirect back to dashboard with success message
            response.sendRedirect("UserDashboard.jsp?msg=Profile updated successfully");
        } else {
            // Redirect back to edit profile page with error message
            response.sendRedirect("EditUserProfile.jsp?error=Failed to update profile");
        }
    }
}
