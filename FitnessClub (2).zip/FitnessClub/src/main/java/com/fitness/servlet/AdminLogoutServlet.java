
package com.fitness.servlet;

import com.fitness.dao.AdminDAO;
import com.fitness.dao.AdminDAOImpl;
import com.fitness.dto.Admin;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/logoutAdminServlet")
public class AdminLogoutServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        response.sendRedirect("LoginAdmin.jsp?success=Logged out successfully");
    }
}
