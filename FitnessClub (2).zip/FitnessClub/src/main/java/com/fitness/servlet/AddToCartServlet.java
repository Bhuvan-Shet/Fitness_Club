package com.fitness.servlet;

import com.fitness.dao.CartDAO;
import com.fitness.dao.CartDAOImpl;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/addToCartServlet")
public class AddToCartServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        String userEmail = (String) session.getAttribute("userEmail");
        if(userEmail == null){
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        int productId = Integer.parseInt(req.getParameter("productId"));
        int quantity = Integer.parseInt(req.getParameter("quantity"));

        CartDAO cartDAO = new CartDAOImpl();
        boolean added = cartDAO.addToCart(userEmail, productId, quantity);

        if(added){
            resp.sendRedirect(req.getContextPath() + "/cart.jsp");
        } else {
            resp.getWriter().println("Error adding product to cart");
        }
    }
}
