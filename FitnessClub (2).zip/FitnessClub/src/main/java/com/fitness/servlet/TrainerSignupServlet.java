package com.fitness.servlet;

import com.fitness.dao.TrainerDAO;
import com.fitness.dao.TrainerDAOImpl;
import com.fitness.dto.Trainer;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/signupTrainerServlet")
public class TrainerSignupServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String specialization = request.getParameter("specialization");
        String password = request.getParameter("password");

        Trainer trainer = new Trainer();
        trainer.setName(name);
        trainer.setEmail(email);
        trainer.setPhone(phone);
        trainer.setSpecialization(specialization);
        trainer.setPassword(password);

        TrainerDAO trainerDAO = new TrainerDAOImpl();
        boolean isRegistered = trainerDAO.signup(trainer);

        if (isRegistered) {
            response.sendRedirect("LoginTrainer.jsp?success=Signup successful");
        } else {
            response.sendRedirect("SignupTrainer.jsp?error=Signup failed");
        }
    }
}