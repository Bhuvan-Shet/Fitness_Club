package com.fitness.servlet;



import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fitness.dao.TrainerAppointmentDAO;
import com.fitness.dao.TrainerAppointmentDAOImpl;
import com.fitness.dto.TrainerAppointment;

@WebServlet("/bookTrainerServlet")
public class BookTrainerServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession(false);
        String userEmail = (String) session.getAttribute("userEmail");

        int trainerId = Integer.parseInt(request.getParameter("trainerId"));
        int months = Integer.parseInt(request.getParameter("months"));
        int hoursPerDay = Integer.parseInt(request.getParameter("hoursPerDay"));

        TrainerAppointment app = new TrainerAppointment();
        app.setUserEmail(userEmail);
        app.setTrainerId(trainerId);
        app.setMonths(months);
        app.setHoursPerDay(hoursPerDay);
        app.setStatus("Pending");

       TrainerAppointmentDAO dao = new TrainerAppointmentDAOImpl();
        boolean success = dao.bookAppointment(app);

        if (success) {
            response.sendRedirect("UserDashboard.jsp?msg=Trainer booked successfully");
        } else {
            response.sendRedirect("BookTrainer.jsp?error=Booking failed");
        }
    }
}
